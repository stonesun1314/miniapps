// pages/product-list/product-list.js
const Zan = require('../../vendor/ZanUI/index');
const app = getApp();

Page(Object.assign({}, Zan.TopTips, app.Methods, {
	data: Object.assign({}, app.Variables, {
		products: null,
		bottomStyle: 'loading'
	}),
	page: 1,
	title: '',
	url: 'product_list',
	params: {},
	options: null,
	goProductDetail(e) {
		app.goProductDetail(e);
	},
	addToCart(e) {
		this.doAddToCart(e, () => {
			this.setData({ cart_quantity: app.data.cart_quantity });
		});
	},
	goCart: () => {
		wx.switchTab({
			url: '../../pages/cart/cart'
		})
	},
	goTop() {
		wx.pageScrollTo({
			scrollTop: 0
		})
	},
	loadData() {
		var params;
		switch (this.options.mode) {
			case 'all':
				this.title = '所有产品';
				break;
			case 'search':
				this.url = 'product_search';
				this.title = '搜索 "' + this.options.search + '"';
				this.params.term = this.options.search;
				break;
			case 'category':
				this.title = decodeURIComponent(this.options.name);
				this.params.category = this.options.id;
				break;
			case 'featured':
				this.title = '精选产品';
				this.params.featured = true;
				break;
			case 'sale':
				this.title = '促销产品';
				this.params.sale = true;
				break;
		}
		if (this.title != 'undefined') {
			wx.setNavigationBarTitle({
				title: this.title,
			})
		}

		app.Util.network.GET({
			url: app.API(this.url),
			params: this.params,
			success: data => {
				wx.showLoading({
					title: '正在加载',
				})

				var products = this.data.products;
				for (var i = 0; i < data.length; i++) {
					products.push(data[i]);
				}

				this.setData({
					products: products
				}, () => {
					wx.hideLoading();
				});
				if (this.page == 1 && data.length == 0) {
					wx.showToast({
						icon: 'none',
						title: '暂无产品'
					})
				}
				if (data.length > 0) {
					this.page++;
					this.params.page = this.page;
				}
				else {
					this.setData({ bottomStyle: 'nomore' });
				}

			}
		});
	},
	onLoad(options) {

		if (app.data.cart != null) {
			wx.showLoading({
				title: '正在加载',
				mask: true
			})
			this.setData({
				cart: app.data.cart
			}, () => {
				wx.hideLoading();
			});
		}
		else {
			app.checkLogin({
				success: () => {
					app.refreshCart(cart => {
						this.setData({ cart_quantity: app.data.cart_quantity });
					});
				}
			})
		}

		this.options = options;
		this.page = 1;
		this.params = { page: this.page };
		this.setData({
			currency: app.data.currency,
			products: [],
			bottomStyle: 'loading'
		});
		this.loadData();
	},
	onShow() {
		this.setData({ cart_quantity: app.data.cart_quantity });
	},
	onPullDownRefresh() {
		this.onLoad(this.options);
	},
	onReachBottom() {
		if (this.data.bottomStyle != 'nomore') {
			this.loadData();
		}
	},
	onShareAppMessage() {

	}
}))