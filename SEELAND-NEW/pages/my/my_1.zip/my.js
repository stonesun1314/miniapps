// pages/my.js
const app = getApp();

Page(Object.assign({}, app.Methods, {
	data: Object.assign({}, app.Variables, {
		userInfo: null
	}),
	goOrderList() {
		wx.navigateTo({
			url: '../../pages/order-list/order-list?status=all',
		})
	},
	goAbout() {
		wx.navigateTo({
			url: '../../pages/about/about',
		})
	},
	onLoad(options) {
		this.setData({ userInfo: app.data.userInfo });
		app.checkLogin({
			fail: () => {
				wx.login({
					success:(res)=>{
						app.data.js_code=res.code
					}
				})
			}
		});
	},
	onShow() {

	},
	onPullDownRefresh() {

	},
	onReachBottom() {

	}
}))